package Ejercio abstract;

public interface PrestaLibro {
    public void prestar();
    public void devolver();
    public void prestado();
}
