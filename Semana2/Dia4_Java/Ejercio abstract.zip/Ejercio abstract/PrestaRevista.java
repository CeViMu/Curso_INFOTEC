package Ejercio abstract;

public interface PrestaRevista {
    public void prestar();
    public void devolver();
    public void numero();
}
