public class Main {
    /**
     * @param args
     */
    public static void main(String[] args) {
        Cancion primerCancion = new Cancion("Monotonía", "Shakira", "Shakira", 2.38, 2022);
        Clase2 adicionalesCancion = new Clase2();

    }
}
