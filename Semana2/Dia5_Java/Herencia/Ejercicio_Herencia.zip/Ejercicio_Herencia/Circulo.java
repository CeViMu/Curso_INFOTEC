package Semana2.Dia5_Java.Herencia.Ejercicio_Herencia;

public class Circulo {
    Integer radio;
    static double pi = 3.1416;

    public static double areaCirculo(Integer radio){
        return (radio^2)*pi;
    }
}
