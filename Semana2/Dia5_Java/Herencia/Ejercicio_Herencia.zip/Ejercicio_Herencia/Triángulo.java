package Semana2.Dia5_Java.Herencia.Ejercicio_Herencia;

public class Triángulo extends Figura{
    
    public Triángulo(Integer alto, Integer ancho){
        super(ancho, alto);
    }
    
}
