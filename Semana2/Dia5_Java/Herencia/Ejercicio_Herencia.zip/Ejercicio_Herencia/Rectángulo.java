package Semana2.Dia5_Java.Herencia.Ejercicio_Herencia;

public class Rectángulo extends Figura{
    
    public Rectángulo(Integer ancho, Integer alto){
        super(ancho, alto);
    }

    
}
