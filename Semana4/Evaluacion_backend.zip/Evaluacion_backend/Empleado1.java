package Semana4.Evaluacion_backend;

import java.util.ArrayList;

public class Empleado1 extends Empleado{

    public void venderProducto(){
    }

    public void acomodarProductos(){
    }

    public void Descansar(){
    }

    public void Sentarse(){
    }
}
