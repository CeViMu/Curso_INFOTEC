package Semana4.Evaluacion_backend;

public class Empleado2 {
    public void venderProducto(){
    }

    public void correr(){
    }

    public void Descansar(){
    }
}
