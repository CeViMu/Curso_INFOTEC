package Semana4.Dia7y8_Java.ArchivosJson;

import java.io.FileReader;

public class JSONParser {

    public Object parse(FileReader fileReader) {
        return null;
    }

}
