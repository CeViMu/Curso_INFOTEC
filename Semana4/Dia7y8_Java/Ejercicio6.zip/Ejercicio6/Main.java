package Semana4.Dia7y8_Java.Ejercicio6;

public class Main {
    public static void main(String[] args) {
        Pelicula.setDuracion(2);
    }
}
