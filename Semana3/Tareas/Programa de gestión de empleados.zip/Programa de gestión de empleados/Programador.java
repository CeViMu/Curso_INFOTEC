package Semana3.Tareas.Programa de gestión de empleados;

public class Programador extends Empleado{
    static String herramientasDesarrollo = "Eclipse";
    Programador instanciaProgramador = new Programador();
    instanciaProgramador.codigo = 9000;
    instanciaProgramador.actDiarias = "Análisis de requerimientos. Desarrollo de requerimientos. Presentación-pruebas unitarias";
    
    
}
