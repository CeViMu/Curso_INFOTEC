package Semana3.Tareas.Programa de gestión de empleados;

public class Diseñador extends Empleado{
    static String herramientasDisenio = "Photoshop";
    Diseñador instDiseñador = new Diseñador();
    instDiseñador.codigo = 800;
    instDiseñador.actDiarias = "Reuniones de avance, Elaboración de diseño para pagonas webs, Presentación-ajustes del diseño";
    
    
}
